--Ritual of the Matador
function c511000010.initial_effect(c)
	aux.AddRitualProcGreater(c,aux.FilterBoolFunction(Card.IsCode,511000009))
end
