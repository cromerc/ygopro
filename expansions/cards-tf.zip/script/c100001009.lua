--リトマスの死儀式
function c100001009.initial_effect(c)
	aux.AddRitualProcGreater(c,aux.FilterBoolFunction(Card.IsCode,100001010))
end
